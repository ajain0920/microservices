package com.controller;

 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.model.Department;

@Controller
@RequestMapping("/deptapp")
public class DepartmentApp {
	
	private static Map<String, List<Department>> dptDB= new HashMap<String, List<Department>>();
	
	
	static {
		dptDB= new HashMap<String, List<Department>>();
		List<Department> lst= new ArrayList<Department>();
		
		Department dept= new Department("HR", "Bangalore", "manager-1");
		lst.add(dept);
		dept= new Department("Finance", "Hyderabad", "manager-2");
		lst.add(dept);
		dptDB.put("boaindia", lst);
		
		lst= new ArrayList<Department>();
		dept= new Department("Tech", "Delhi", "manager-3");
		lst.add(dept);
		dept= new Department("Healthcare", "Chennai", "manager-4");
		lst.add(dept);
		dptDB.put("boaus", lst);
		
	}
	
	@GetMapping("/loaddepts/{location}")
	public List<Department> loadUsers(@PathVariable("location")String location) {
		
		List<Department> dlist= dptDB.get(location);
		if(dlist == null) {
			dlist= new ArrayList<Department>();
			Department d= new Department("Not Found", "NA", "NA");
			dlist.add(d);
		}
		return dlist;

		
	}
	

}
