package com.delegate;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;

@Service
public class AppDelegate {

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "callFallback")
	public String loadUsers() {
		String response = restTemplate.exchange("http://emp-service/mainapp/loadusers", HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
		return response + " " + new Date();
	}
	
	public String callFallback() {
		return "Circuit breaker enabled.. service is down try after some time";
	}
	
	public String loadDept(String location) {
		String response = restTemplate.exchange("http://dept-service/deptapp/loaddepts/{location}", HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
		return response + " " + new Date();
	}
}
