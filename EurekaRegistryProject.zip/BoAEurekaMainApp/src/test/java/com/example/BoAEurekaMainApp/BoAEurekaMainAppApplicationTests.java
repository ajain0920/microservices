package com.example.BoAEurekaMainApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoAEurekaMainAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
