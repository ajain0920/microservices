package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Register;
import com.service.UserService;

@RestController
@RequestMapping("/mainapp")
public class MainAppRes {
	
	@Autowired
	private UserService service;
	
	
	
	@PostMapping("/login")
	 
	public String loginValid(@RequestParam("uname")String name,@RequestParam("pass")String pass) {
		if(service.loginValidated(name, pass)) {
			return "user success";
			
		}
		return "user failed";
	}
     @PostMapping("/register")
	public String addUser(@RequestParam("uname")String name,@RequestParam("pass")String pass,@RequestParam("email")String email,@RequestParam("city")String city)
	
	{
		Register register= new Register(name, pass, email, city);
		service.addUser(register);
		return "user added";
	}
     @GetMapping("/loadusers")
     public List<Register> loadUsers(){
    	 return service.loadUsers();
     }
     
     @GetMapping("/searchuser/{name}")
     public String searchUser(@PathVariable("name")String name) {
    	 
    	 if(service.finduser(name)) {
    		 return "user found";
    	 }
    	 return "user not found";
    	 
     }
    
    
     
     
     
     
     
}
