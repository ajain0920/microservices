package com.example.BoARegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoARegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
