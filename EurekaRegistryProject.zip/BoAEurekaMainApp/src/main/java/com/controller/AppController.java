package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.delegate.AppDelegate;

@RestController
public class AppController {

	
	@Autowired
	AppDelegate appDelegate;
	
	@GetMapping("/loadusers")
	public String loadUsers() {
		return appDelegate.loadUsers();
	}

	@GetMapping("/loaddepartments/{location}")
	public String loadDepartments(@PathVariable("location") String location) {
		return appDelegate.loadDept(location);
	}
}

