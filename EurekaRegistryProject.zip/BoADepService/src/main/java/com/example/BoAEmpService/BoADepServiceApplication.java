package com.example.BoAEmpService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class BoADepServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoADepServiceApplication.class, args);
	}

}
