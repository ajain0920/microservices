package com.model;

public class Department {
	
	private String dName;
	private String location;
	private String managerName;
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public Department(String dName, String location, String managerName) {
		super();
		this.dName = dName;
		this.location = location;
		this.managerName = managerName;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
